#!/bin/bash
# Converte
convert bash_logo.jpg bash_logo_pbm_binary.pbm
convert bash_logo.jpg bash_logo_ppm_binary.ppm
