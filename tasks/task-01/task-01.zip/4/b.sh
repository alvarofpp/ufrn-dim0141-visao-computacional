#!/bin/bash
# Converte
convert -compress none bash_logo.jpg bash_logo_pbm_ascii.pbm
# Exibe
display bash_logo_pbm_ascii.pbm
